echo Restoring environment
unset LD_LIBRARY_PATH
unset DYLD_LIBRARY_PATH
unset GRPC_DEFAULT_SSL_ROOTS_FILE_PATH
unset OPENSSL_MODULES
export PATH='/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin:/sbin:/bin:/root/.local/share/pipx/venvs/conan/bin'
